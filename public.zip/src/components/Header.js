import React, {Component, Fragment} from 'react'
import {Nav, Navbar} from 'react-bootstrap'
import {connect} from 'react-redux'
import {logoutUser} from '../redux/actions/loggedUserAction'

class Navigation extends Component {

    logout = () => {
        this.props.logoutUser()
    }

    render() {
        return (
            <div>
                <Navbar>
                    <Navbar.Collapse>
                        <Nav className="mr-auto">
                            <Nav.Link to="/">Home</Nav.Link>
                            <Nav.Link to="add">New Question</Nav.Link>
                            <Nav.Link to="leaderboard">Leaderboard</Nav.Link>
                        </Nav>
                        <Navbar.Toggle/>
                        {this.props.username &&
                        <Navbar.Collapse className="justify-content-end">
                            <Navbar.Text>
                                Hello, {this.props.username}!
                            </Navbar.Text>
                            <Nav.Link href="/" onClick={this.logout}>LogOut</Nav.Link>
                        </Navbar.Collapse>}
                    </Navbar.Collapse>
                </Navbar>
                <hr/>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    const loggedUser = state.loggedUser;
    return {
        loggedUser: loggedUser,
        username: state.users[loggedUser] ? state.users[loggedUser].name : null,
        avatar: state.users[loggedUser] ? state.users[loggedUser].avatarURL : null
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        logoutUser: () => dispatch(logoutUser())
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Navigation)