import React, {Component} from 'react'
import { Card, } from 'react-bootstrap'
import {connect} from 'react-redux'


class Profile extends Component {
    render() {

        return (
            <Card style={{width: '18rem'}}>
                <Card.Img variant="top" src={this.props.avatar}/>
                <Card.Body>
                    <Card.Title>{this.props.username}</Card.Title>
                    <Card.Text>
                        <p>Answered Questions : {this.props.answered}</p>
                        <p> UnAnswered Questions: {this.props.unanswered}</p>
                    </Card.Text>
                </Card.Body>
            </Card>
        )
    }
}

const mapStateToProps = (state) => {
    const loggedUser = state.loggedUser;
    return {
        username: state.users[loggedUser] ? state.users[loggedUser].name : null,
        avatar: state.users[loggedUser] ? state.users[loggedUser].avatarURL : null,
        answered: state.categorizeQuestions.answeredQuestions.length,
        unanswered: state.categorizeQuestions.unansweredquestions.length
    }
}

export default connect(mapStateToProps)(Profile)
