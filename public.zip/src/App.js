import React, {Component} from 'react';
import './App.css';
import {fetchInitialData} from './redux/actions/asyncCallAction'
import {BrowserRouter,  Route, Switch} from 'react-router-dom'
import {connect} from 'react-redux'
import SignIn from './components/signin'
import LoadingBar from 'react-redux-loading-bar'
import Navigation from './components/Header'
import Home from './components/home'
import QuestionContainer from './components/routeQuestions'
import add from './components/newQuestion'
import {categorizeQuestions} from '../src/redux/actions/questionActions'
import LeaderBoard from './components/leaderboard'

class App extends Component {

    componentDidMount() {
        this.props.getInitialData()
    }

    componentWillReceiveProps(props){
        if(props.loggedUser != null){
            props.categorizeQuestions(props.questions, props.loggedUser, props.users)}
    }

    render() {
        console.log(this.props.displayLogin)
        return (
            <BrowserRouter>
            <div className="login-container">
                <LoadingBar className="loading"/>
                {this.props.displayLogin ? null : <Navigation/>}
                {this.props.loading === true ? null :
                    this.props.displayLogin ? <SignIn/> :
                        <Switch>
                            <Route exact path='/' component={Home}/>
                            <Route exact path='/add' component={add}/>
                            <Route exact path='/leaderboard' component={LeaderBoard}/>
                            <Route exact path='/questions/:questionId' component={QuestionContainer}/>
                        </Switch>
                }
            </div>
            </BrowserRouter>
        );
    }
}

const mapStateToProps = (state) => {
    console.log(state)
    return {
        loading: Object.keys(state.questions).length === 0,
        displayLogin: (state.loggedUser != null) ? false : true,
        users: state.users,
        questions: state.questions,
        loggedUser: state.loggedUser
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        getInitialData: () => dispatch(fetchInitialData()),
        categorizeQuestions: (questions,loggeduser,users) => dispatch(categorizeQuestions(questions,loggeduser,users))
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
