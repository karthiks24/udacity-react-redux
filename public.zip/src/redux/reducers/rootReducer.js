import { combineReducers } from 'redux'
import users from '../reducers/usersReducer'
import questions  from '../reducers/questionsReducer'
import loggedUser, {categorizeQuestions} from '../reducers/loggedUserReducer'
import { loadingBarReducer } from 'react-redux-loading-bar'

export default combineReducers({
    users,
    questions,
    loggedUser,
    categorizeQuestions,
    loadingBar: loadingBarReducer,
})
