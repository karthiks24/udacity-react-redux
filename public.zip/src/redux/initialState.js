export  const initialState ={
    users:{},
    questions:{},
    loggedUser:null,
    categorize: {
        answeredQuestions: [],
        unAnsweredQuestions: []
    }
}