import {_getQuestions, _getUsers, _saveQuestion, _saveQuestionAnswer} from '../../utils/_DATA'
import {hideLoading, showLoading} from 'react-redux-loading-bar'
import {loadUsers, saveUserAnswer, saveUserQuestion} from './usersActions'
import {loadQuestions, saveQuestion, saveVote, categorizeQuestions} from './questionActions'

 function fetchUsers() {
    return async dispatch => {
        try{
         const users = await  (_getUsers());
         return dispatch(loadUsers(users))
        }
        catch(error){
            console.log(error)
        }
    }
}

function fetchQuestions() {
    return async dispatch => {
        try{
            const questions = await _getQuestions();
            return dispatch(loadQuestions(questions))
        } 
        catch(error){
            console.log(error)
        }
    }
}

export function fetchInitialData() {
    console.log('inside')
    return (dispatch) => Promise.all([
        dispatch(showLoading()),
        dispatch(fetchUsers()),
        dispatch(fetchQuestions())
    ]).then(() => {
        dispatch(hideLoading())
    })
}

export function handleVote(loggedUser, question, answer) {
    console.log(loggedUser);
    console.log(question)
        console.log(answer)

    return async dispatch => {
        const savedQuestion= await _saveQuestionAnswer({authedUser: loggedUser,
            qid: question.id,
            answer: answer})
        try{
                dispatch(showLoading());
                dispatch(saveUserAnswer(loggedUser, question.id, answer));
                dispatch(saveVote(loggedUser, question.id, answer));
                dispatch(hideLoading())
        }
        catch(error)  {
            alert('Oops! There was an error. Please try again.')
        }
    }
}

/* async call to save new user question */
export function addQuestion(author, optionOne, optionTwo) {
    const question = {
        author: author,
        optionOneText: optionOne,
        optionTwoText: optionTwo
    }
    return async dispatch => {
        const savedQuestion= await _saveQuestion(question)
        try{
            dispatch(saveQuestion(savedQuestion))
            dispatch(saveUserQuestion(savedQuestion.author, savedQuestion.id))
        }
    catch(error)  {
            alert('Oops! There was an error. Please try again.')
            console.log(error)
        }
    }
}
